import { NextResponse } from 'next/server';
import { v4 as uuidv4 } from 'uuid';
import { getCollection } from '@/lib/db';
import { hashPassword, verifyPassword, generateToken, getCurrentUser, ROLES, hasPermission, canManageRole } from '@/lib/auth';
import { seedDatabase } from '@/lib/seed';

// CORS headers
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

function jsonResponse(data, status = 200) {
  return NextResponse.json(data, { status, headers: corsHeaders });
}

function errorResponse(message, status = 400) {
  return NextResponse.json({ error: message }, { status, headers: corsHeaders });
}

async function logActivity(userId, userName, action, description, entityType, entityId) {
  const activities = await getCollection('activities');
  await activities.insertOne({
    id: uuidv4(),
    userId,
    userName,
    action,
    description,
    entityType,
    entityId,
    createdAt: new Date().toISOString()
  });
}

export async function OPTIONS() {
  return new NextResponse(null, { status: 200, headers: corsHeaders });
}

export async function GET(request) {
  const { pathname, searchParams } = new URL(request.url);
  const path = pathname.replace('/api', '');

  try {
    // Health check
    if (path === '/health' || path === '/') {
      return jsonResponse({ status: 'ok', timestamp: new Date().toISOString() });
    }

    // Seed database
    if (path === '/seed') {
      const result = await seedDatabase();
      return jsonResponse(result);
    }

    // Get current user
    if (path === '/auth/me') {
      const user = await getCurrentUser(request);
      if (!user) return errorResponse('Unauthorized', 401);
      return jsonResponse({ user });
    }

    // Dashboard stats
    if (path === '/dashboard/stats') {
      const user = await getCurrentUser(request);
      if (!user) return errorResponse('Unauthorized', 401);

      const leads = await getCollection('leads');
      const users = await getCollection('users');

      let matchQuery = {};
      if (user.role === ROLES.EMPLOYEE) {
        matchQuery = { assignedTo: user.id };
      }

      // Use aggregation for efficient stats calculation
      const statusAgg = await leads.aggregate([
        { $match: matchQuery },
        { $group: { _id: '$status', count: { $sum: 1 } } }
      ]).toArray();

      const genderAgg = await leads.aggregate([
        { $match: matchQuery },
        { $group: { _id: '$gender', count: { $sum: 1 } } }
      ]).toArray();

      const employeeAgg = await leads.aggregate([
        { $match: matchQuery },
        { $group: { 
          _id: '$assignedTo', 
          name: { $first: '$assignedToName' },
          total: { $sum: 1 },
          interested: { $sum: { $cond: [{ $eq: ['$status', 'INTERESTED'] }, 1, 0] } }
        }}
      ]).toArray();

      const totalLeads = await leads.countDocuments(matchQuery);
      const statusMap = {};
      statusAgg.forEach(s => { statusMap[s._id] = s.count; });
      
      const interested = statusMap['INTERESTED'] || 0;
      const notInterested = statusMap['NOT_INTERESTED'] || 0;
      const noAnswer = statusMap['NO_ANSWER'] || 0;
      const phoneOff = statusMap['PHONE_OFF'] || 0;
      const newLeads = statusMap['NEW'] || 0;
      
      const genderMap = {};
      genderAgg.forEach(g => { genderMap[g._id] = g.count; });
      const male = genderMap['MALE'] || 0;
      const female = genderMap['FEMALE'] || 0;

      const conversionRate = totalLeads > 0 ? Math.round((interested / totalLeads) * 100) : 0;

      const employeePerformance = employeeAgg
        .filter(e => e._id)
        .map(e => ({
          name: e.name || 'Unknown',
          total: e.total,
          interested: e.interested,
          conversionRate: e.total > 0 ? Math.round((e.interested / e.total) * 100) : 0
        }))
        .sort((a, b) => b.conversionRate - a.conversionRate)
        .slice(0, 10);

      const totalUsers = await users.countDocuments();

      return jsonResponse({
        totalLeads,
        interested,
        notInterested,
        noAnswer,
        phoneOff,
        newLeads,
        conversionRate,
        genderDistribution: { male, female },
        statusDistribution: [
          { name: 'Interested', value: interested },
          { name: 'Not Interested', value: notInterested },
          { name: 'No Answer', value: noAnswer },
          { name: 'Phone Off', value: phoneOff },
          { name: 'New', value: newLeads }
        ],
        employeePerformance,
        totalUsers
      });
    }

    // Get leads
    if (path === '/leads') {
      const user = await getCurrentUser(request);
      if (!user) return errorResponse('Unauthorized', 401);

      const leads = await getCollection('leads');
      const page = parseInt(searchParams.get('page') || '1');
      const limit = parseInt(searchParams.get('limit') || '10');
      const status = searchParams.get('status');
      const search = searchParams.get('search');
      const skip = (page - 1) * limit;

      let query = {};
      
      if (user.role === ROLES.EMPLOYEE) {
        query.assignedTo = user.id;
      }

      if (status && status !== 'ALL') {
        query.status = status;
      }

      if (search) {
        query.$or = [
          { fullName: { $regex: search, $options: 'i' } },
          { phone: { $regex: search, $options: 'i' } },
          { city: { $regex: search, $options: 'i' } }
        ];
      }

      const total = await leads.countDocuments(query);
      const items = await leads.find(query)
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .toArray();

      return jsonResponse({
        items,
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit)
      });
    }

    // Export leads as CSV (must come before single lead check)
    if (path === '/leads/export') {
      const user = await getCurrentUser(request);
      if (!user) return errorResponse('Unauthorized', 401);

      const leads = await getCollection('leads');
      let query = {};
      if (user.role === ROLES.EMPLOYEE) {
        query = { assignedTo: user.id };
      }

      const items = await leads.find(query, {
        projection: { fullName: 1, phone: 1, city: 1, age: 1, gender: 1, status: 1, notes: 1, assignedToName: 1, createdAt: 1 }
      }).limit(10000).toArray();
      
      const headers = ['Full Name', 'Phone', 'City', 'Age', 'Gender', 'Status', 'Notes', 'Assigned To', 'Created At'];
      const rows = items.map(l => [
        l.fullName,
        l.phone,
        l.city,
        l.age,
        l.gender,
        l.status,
        l.notes || '',
        l.assignedToName || '',
        l.createdAt
      ]);

      const csv = [headers.join(','), ...rows.map(r => r.map(c => `"${c}"`).join(','))].join('\n');

      return new NextResponse(csv, {
        status: 200,
        headers: {
          ...corsHeaders,
          'Content-Type': 'text/csv',
          'Content-Disposition': 'attachment; filename=leads.csv'
        }
      });
    }

    // Get single lead
    if (path.startsWith('/leads/') && path.split('/').length === 3) {
      const user = await getCurrentUser(request);
      if (!user) return errorResponse('Unauthorized', 401);

      const leadId = path.split('/')[2];
      const leads = await getCollection('leads');
      const lead = await leads.findOne({ id: leadId });

      if (!lead) return errorResponse('Lead not found', 404);

      if (user.role === ROLES.EMPLOYEE && lead.assignedTo !== user.id) {
        return errorResponse('Access denied', 403);
      }

      return jsonResponse(lead);
    }

    // Get users
    if (path === '/users') {
      const user = await getCurrentUser(request);
      if (!user) return errorResponse('Unauthorized', 401);
      if (user.role === ROLES.VIEWER || user.role === ROLES.EMPLOYEE) {
        return errorResponse('Access denied', 403);
      }

      const users = await getCollection('users');
      const items = await users.find({}, { projection: { password: 0 } }).limit(500).toArray();
      return jsonResponse({ items });
    }

    // Get messages
    if (path === '/messages') {
      const user = await getCurrentUser(request);
      if (!user) return errorResponse('Unauthorized', 401);

      const messages = await getCollection('messages');
      const inbox = await messages.find({
        $or: [
          { toId: user.id },
          { isBroadcast: true }
        ]
      }).sort({ createdAt: -1 }).toArray();

      const sent = await messages.find({ fromId: user.id })
        .sort({ createdAt: -1 }).toArray();

      return jsonResponse({ inbox, sent });
    }

    // Get activities
    if (path === '/activities') {
      const user = await getCurrentUser(request);
      if (!user) return errorResponse('Unauthorized', 401);
      if (user.role !== ROLES.SUPER_ADMIN && user.role !== ROLES.ADMIN) {
        return errorResponse('Access denied', 403);
      }

      const activities = await getCollection('activities');
      const limit = parseInt(searchParams.get('limit') || '50');
      const items = await activities.find({})
        .sort({ createdAt: -1 })
        .limit(limit)
        .toArray();

      return jsonResponse({ items });
    }

    return errorResponse('Not found', 404);

  } catch (error) {
    console.error('API Error:', error);
    return errorResponse(error.message || 'Internal server error', 500);
  }
}

export async function POST(request) {
  const { pathname } = new URL(request.url);
  const path = pathname.replace('/api', '');

  try {
    const body = await request.json().catch(() => ({}));

    // Login
    if (path === '/auth/login') {
      const { email, password } = body;
      if (!email || !password) {
        return errorResponse('Email and password required');
      }

      const users = await getCollection('users');
      const user = await users.findOne({ email });

      if (!user) return errorResponse('Invalid credentials', 401);

      const isValid = await verifyPassword(password, user.password);
      if (!isValid) return errorResponse('Invalid credentials', 401);

      const token = generateToken(user);

      await logActivity(user.id, user.name, 'LOGIN', 'User logged in', 'USER', user.id);

      return jsonResponse({
        token,
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role
        }
      });
    }

    // Create user
    if (path === '/users') {
      const currentUser = await getCurrentUser(request);
      if (!currentUser) return errorResponse('Unauthorized', 401);

      const { email, password, name, role } = body;
      if (!email || !password || !name || !role) {
        return errorResponse('All fields required');
      }

      // Check permissions
      if (currentUser.role === ROLES.VIEWER || currentUser.role === ROLES.EMPLOYEE) {
        return errorResponse('Access denied', 403);
      }

      if (currentUser.role === ROLES.ADMIN && (role === ROLES.SUPER_ADMIN || role === ROLES.ADMIN)) {
        return errorResponse('Cannot create admin users', 403);
      }

      const users = await getCollection('users');
      const existing = await users.findOne({ email });
      if (existing) return errorResponse('Email already exists');

      const hashedPassword = await hashPassword(password);
      const newUser = {
        id: uuidv4(),
        email,
        password: hashedPassword,
        name,
        role,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      await users.insertOne(newUser);
      await logActivity(currentUser.id, currentUser.name, 'USER_CREATED', `Created user: ${name}`, 'USER', newUser.id);

      const { password: _, ...userWithoutPassword } = newUser;
      return jsonResponse(userWithoutPassword, 201);
    }

    // Create lead
    if (path === '/leads') {
      const currentUser = await getCurrentUser(request);
      if (!currentUser) return errorResponse('Unauthorized', 401);

      if (currentUser.role === ROLES.VIEWER) {
        return errorResponse('Access denied', 403);
      }

      const { fullName, phone, city, age, gender, assignedTo, assignedToName } = body;
      if (!fullName || !phone) {
        return errorResponse('Full name and phone required');
      }

      const leads = await getCollection('leads');
      const newLead = {
        id: uuidv4(),
        fullName,
        phone,
        city: city || '',
        age: age || null,
        gender: gender || 'MALE',
        status: 'NEW',
        notes: '',
        assignedTo: assignedTo || currentUser.id,
        assignedToName: assignedToName || currentUser.name,
        createdBy: currentUser.id,
        createdByName: currentUser.name,
        updatedBy: currentUser.id,
        updatedByName: currentUser.name,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      await leads.insertOne(newLead);
      await logActivity(currentUser.id, currentUser.name, 'LEAD_CREATED', `Created lead: ${fullName}`, 'LEAD', newLead.id);

      return jsonResponse(newLead, 201);
    }

    // Send message
    if (path === '/messages') {
      const currentUser = await getCurrentUser(request);
      if (!currentUser) return errorResponse('Unauthorized', 401);

      const { toId, toName, subject, content, isBroadcast } = body;
      
      if (isBroadcast && currentUser.role !== ROLES.SUPER_ADMIN) {
        return errorResponse('Only Super Admin can broadcast', 403);
      }

      if (!isBroadcast && (!toId || !subject || !content)) {
        return errorResponse('Recipient, subject, and content required');
      }

      const messages = await getCollection('messages');
      const newMessage = {
        id: uuidv4(),
        fromId: currentUser.id,
        fromName: currentUser.name,
        toId: isBroadcast ? null : toId,
        toName: isBroadcast ? 'All Users' : toName,
        subject,
        content,
        isBroadcast: isBroadcast || false,
        read: false,
        createdAt: new Date().toISOString()
      };

      await messages.insertOne(newMessage);
      await logActivity(currentUser.id, currentUser.name, 'MESSAGE_SENT', 
        isBroadcast ? 'Broadcast message sent' : `Message sent to ${toName}`, 
        'MESSAGE', newMessage.id);

      return jsonResponse(newMessage, 201);
    }

    return errorResponse('Not found', 404);

  } catch (error) {
    console.error('API Error:', error);
    return errorResponse(error.message || 'Internal server error', 500);
  }
}

export async function PUT(request) {
  const { pathname } = new URL(request.url);
  const path = pathname.replace('/api', '');

  try {
    const currentUser = await getCurrentUser(request);
    if (!currentUser) return errorResponse('Unauthorized', 401);

    const body = await request.json().catch(() => ({}));

    // Update lead status
    if (path.startsWith('/leads/') && path.endsWith('/status')) {
      const leadId = path.split('/')[2];
      const { status, notes } = body;

      if (!status) return errorResponse('Status required');

      const leads = await getCollection('leads');
      const lead = await leads.findOne({ id: leadId });

      if (!lead) return errorResponse('Lead not found', 404);

      if (currentUser.role === ROLES.EMPLOYEE && lead.assignedTo !== currentUser.id) {
        return errorResponse('Access denied', 403);
      }

      if (currentUser.role === ROLES.VIEWER) {
        return errorResponse('Access denied', 403);
      }

      const update = {
        status,
        updatedBy: currentUser.id,
        updatedByName: currentUser.name,
        updatedAt: new Date().toISOString()
      };

      if (status === 'INTERESTED' && notes) {
        update.notes = notes;
      }

      await leads.updateOne({ id: leadId }, { $set: update });
      await logActivity(currentUser.id, currentUser.name, 'LEAD_STATUS_UPDATED', 
        `Updated lead status to ${status}`, 'LEAD', leadId);

      return jsonResponse({ ...lead, ...update });
    }

    // Update lead
    if (path.startsWith('/leads/') && path.split('/').length === 3) {
      const leadId = path.split('/')[2];
      const leads = await getCollection('leads');
      const lead = await leads.findOne({ id: leadId });

      if (!lead) return errorResponse('Lead not found', 404);

      if (currentUser.role === ROLES.VIEWER) {
        return errorResponse('Access denied', 403);
      }

      if (currentUser.role === ROLES.EMPLOYEE && lead.assignedTo !== currentUser.id) {
        return errorResponse('Access denied', 403);
      }

      const { fullName, phone, city, age, gender, notes, assignedTo, assignedToName } = body;
      const update = {
        ...(fullName && { fullName }),
        ...(phone && { phone }),
        ...(city !== undefined && { city }),
        ...(age !== undefined && { age }),
        ...(gender && { gender }),
        ...(notes !== undefined && { notes }),
        ...(assignedTo && { assignedTo }),
        ...(assignedToName && { assignedToName }),
        updatedBy: currentUser.id,
        updatedByName: currentUser.name,
        updatedAt: new Date().toISOString()
      };

      await leads.updateOne({ id: leadId }, { $set: update });
      await logActivity(currentUser.id, currentUser.name, 'LEAD_UPDATED', 
        `Updated lead: ${fullName || lead.fullName}`, 'LEAD', leadId);

      return jsonResponse({ ...lead, ...update });
    }

    // Update user
    if (path.startsWith('/users/') && path.split('/').length === 3) {
      const userId = path.split('/')[2];

      if (currentUser.role === ROLES.VIEWER || currentUser.role === ROLES.EMPLOYEE) {
        return errorResponse('Access denied', 403);
      }

      const users = await getCollection('users');
      const user = await users.findOne({ id: userId });

      if (!user) return errorResponse('User not found', 404);

      const { name, role, password } = body;
      const update = {
        ...(name && { name }),
        ...(role && { role }),
        updatedAt: new Date().toISOString()
      };

      if (password) {
        update.password = await hashPassword(password);
      }

      await users.updateOne({ id: userId }, { $set: update });
      await logActivity(currentUser.id, currentUser.name, 'USER_UPDATED', 
        `Updated user: ${name || user.name}`, 'USER', userId);

      return jsonResponse({ id: userId, ...update });
    }

    // Mark message as read
    if (path.startsWith('/messages/') && path.endsWith('/read')) {
      const messageId = path.split('/')[2];
      const messages = await getCollection('messages');
      
      await messages.updateOne({ id: messageId }, { $set: { read: true } });
      return jsonResponse({ success: true });
    }

    return errorResponse('Not found', 404);

  } catch (error) {
    console.error('API Error:', error);
    return errorResponse(error.message || 'Internal server error', 500);
  }
}

export async function DELETE(request) {
  const { pathname } = new URL(request.url);
  const path = pathname.replace('/api', '');

  try {
    const currentUser = await getCurrentUser(request);
    if (!currentUser) return errorResponse('Unauthorized', 401);

    // Delete lead
    if (path.startsWith('/leads/')) {
      const leadId = path.split('/')[2];

      if (currentUser.role === ROLES.VIEWER || currentUser.role === ROLES.EMPLOYEE) {
        return errorResponse('Access denied', 403);
      }

      const leads = await getCollection('leads');
      const lead = await leads.findOne({ id: leadId });

      if (!lead) return errorResponse('Lead not found', 404);

      await leads.deleteOne({ id: leadId });
      await logActivity(currentUser.id, currentUser.name, 'LEAD_DELETED', 
        `Deleted lead: ${lead.fullName}`, 'LEAD', leadId);

      return jsonResponse({ success: true });
    }

    // Delete user
    if (path.startsWith('/users/')) {
      const userId = path.split('/')[2];

      if (currentUser.role !== ROLES.SUPER_ADMIN) {
        return errorResponse('Access denied', 403);
      }

      const users = await getCollection('users');
      const user = await users.findOne({ id: userId });

      if (!user) return errorResponse('User not found', 404);
      if (user.id === currentUser.id) {
        return errorResponse('Cannot delete yourself', 400);
      }

      await users.deleteOne({ id: userId });
      await logActivity(currentUser.id, currentUser.name, 'USER_DELETED', 
        `Deleted user: ${user.name}`, 'USER', userId);

      return jsonResponse({ success: true });
    }

    return errorResponse('Not found', 404);

  } catch (error) {
    console.error('API Error:', error);
    return errorResponse(error.message || 'Internal server error', 500);
  }
}
